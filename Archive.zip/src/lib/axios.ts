import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import { getSession, signOut } from 'next-auth/react';

const apiBaseUrl =
  process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000/api/v1';

type RetryableRequestConfig = InternalAxiosRequestConfig & {
  _retry?: boolean;
};

type BackendErrorResponse = {
  success?: boolean;
  message?: string;
  code?: string;
};

const apiClient = axios.create({
  baseURL: apiBaseUrl,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
});

const isAuthEndpoint = (url?: string): boolean => {
  if (!url) return false;

  return (
    url.includes('/auth/login') ||
    url.includes('/auth/refresh') ||
    url.includes('/auth/logout')
  );
};

apiClient.interceptors.request.use(async (config) => {
  const session = await getSession();

  if (session?.error === 'RefreshAccessTokenError') {
    await signOut({
      callbackUrl: '/auth/login',
      redirect: true,
    });

    return config;
  }

  if (session?.accessToken) {
    config.headers.Authorization = `Bearer ${session.accessToken}`;
  } else {
    delete config.headers.Authorization;
  }

  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError<BackendErrorResponse>) => {
    const originalRequest = error.config as RetryableRequestConfig | undefined;

    const status = error.response?.status;
    const code = error.response?.data?.code;

    const isAccessTokenError =
      status === 401 &&
      ['INVALID_ACCESS_TOKEN', 'ACCESS_TOKEN_REQUIRED'].includes(code || '');

    if (!originalRequest || isAuthEndpoint(originalRequest.url)) {
      return Promise.reject(error);
    }

    if (!isAccessTokenError) {
      return Promise.reject(error);
    }

    if (originalRequest._retry) {
      await signOut({
        callbackUrl: '/auth/login',
        redirect: true,
      });

      return Promise.reject(error);
    }

    originalRequest._retry = true;

    const session = await getSession();

    if (!session?.accessToken || session.error === 'RefreshAccessTokenError') {
      await signOut({
        callbackUrl: '/auth/login',
        redirect: true,
      });

      return Promise.reject(error);
    }

    originalRequest.headers.Authorization = `Bearer ${session.accessToken}`;

    return apiClient(originalRequest);
  },
);

export default apiClient;