import apiClient from '@/lib/axios';
import {
  ApiResponse,
  CalendarEvent,
  CreateProjectNotePayload,
  getTaskId,
  PaginationState,
  Project,
  ProjectFile,
  ProjectImportResult,
  ProjectListResponse,
  ProjectPayload,
  ProjectProgressNote,
  ProjectTask,
  ProjectTaskPayload,
} from '@/types/project';

type QueryParams = Record<string, string | number | boolean | undefined | null>;

const defaultPagination: PaginationState = {
  total: 0,
  page: 1,
  limit: 20,
  totalPages: 1,
};

const unwrapData = <T>(responseData: ApiResponse<T> | T): T => {
  if (
    responseData &&
    typeof responseData === 'object' &&
    'data' in responseData
  ) {
    return (responseData as ApiResponse<T>).data as T;
  }

  return responseData as T;
};

const unwrapMessage = (error: unknown, fallback: string): string => {
  const err = error as {
    response?: {
      data?: {
        message?: string;
      };
    };
    message?: string;
  };

  return err.response?.data?.message || err.message || fallback;
};

const normalizeListResponse = (
  responseData: ApiResponse<Project[]> | Project[] | ProjectListResponse,
): ProjectListResponse => {
  if (Array.isArray(responseData)) {
    return {
      items: responseData,
      pagination: defaultPagination,
    };
  }

  if ('items' in responseData && Array.isArray(responseData.items)) {
    return responseData as ProjectListResponse;
  }

  const apiResponse = responseData as ApiResponse<Project[]>;

  return {
    items: Array.isArray(apiResponse.data) ? apiResponse.data : [],
    pagination: apiResponse.pagination || defaultPagination,
  };
};

const getFileTaskId = (file: ProjectFile): string => {
  const taskRef = file.taskId as unknown;

  if (!taskRef) return '';

  if (typeof taskRef === 'string') return taskRef;

  const taskObject = taskRef as {
    id?: string;
    _id?: string;
  };

  return taskObject.id || taskObject._id || '';
};

const attachFilesToTasks = (
  tasks: ProjectTask[],
  files: ProjectFile[],
): ProjectTask[] => {
  const filesByTaskId = files.reduce<Record<string, ProjectFile[]>>(
    (acc, file) => {
      const taskId = getFileTaskId(file);

      if (!taskId) return acc;

      if (!acc[taskId]) acc[taskId] = [];

      acc[taskId].push(file);

      return acc;
    },
    {},
  );

  return tasks.map((task) => {
    const taskId = getTaskId(task);
    const currentFiles = Array.isArray(task.files) ? task.files : [];
    const attachedFiles = filesByTaskId[taskId] || [];

    const mergedFilesMap = new Map<string, ProjectFile>();

    [...currentFiles, ...attachedFiles].forEach((file) => {
      const fileKey = file.id || file._id || file.fileUrl || file.fileName;

      if (fileKey) {
        mergedFilesMap.set(fileKey, file);
      }
    });

    const mergedFiles = Array.from(mergedFilesMap.values());

    return {
      ...task,
      files: mergedFiles,
      attachmentCount: mergedFiles.length,
    };
  });
};

const fetchProjectFiles = async (projectId: string): Promise<ProjectFile[]> => {
  const response = await apiClient.get(`/projects/${projectId}/files`, {
    params: {
      standaloneOnly: false,
    },
  });

  return unwrapData<ProjectFile[]>(response.data) || [];
};

const attachProjectFilesToTask = async (
  projectId: string,
  task: ProjectTask,
): Promise<ProjectTask> => {
  const files = await fetchProjectFiles(projectId);
  const [taskWithFiles] = attachFilesToTasks([task], files);

  return taskWithFiles || task;
};

const uploadTaskFilesRequest = async (
  projectId: string,
  taskId: string,
  files: File[],
): Promise<ProjectTask> => {
  const formData = new FormData();

  files.forEach((file) => {
    formData.append('files', file);
  });

  const response = await apiClient.post(
    `/projects/${projectId}/tasks/${taskId}/files`,
    formData,
    {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    },
  );

  const task = unwrapData<ProjectTask>(response.data);

  return attachProjectFilesToTask(projectId, task);
};

const buildTaskRequestPayload = (payload: Partial<ProjectTaskPayload>) => {
  const requestPayload: Record<string, unknown> = {};

  if (payload.title !== undefined) {
    requestPayload.title = payload.title;
  }

  if (payload.description !== undefined) {
    requestPayload.description = payload.description || '';
  }

  if (payload.assignedUserIds !== undefined) {
    requestPayload.assignedUserIds = payload.assignedUserIds || [];
  }

  if (payload.status !== undefined) {
    requestPayload.status = payload.status;
  }

  if (payload.priority !== undefined) {
    requestPayload.priority = payload.priority;
  }

  if (payload.startDate !== undefined) {
    requestPayload.startDate = payload.startDate || null;
  }

  if (payload.dueDate !== undefined) {
    requestPayload.dueDate = payload.dueDate || null;
  }

  return requestPayload;
};

export const projectService = {
  async listProjects(params?: QueryParams): Promise<ProjectListResponse> {
    try {
      const response = await apiClient.get('/projects', { params });

      return normalizeListResponse(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در دریافت پروژه‌ها'));
    }
  },

  async createProject(payload: ProjectPayload): Promise<Project> {
    try {
      const response = await apiClient.post('/projects', {
        ...payload,
        dueDate: payload.dueDate || null,
        assignedUserIds: payload.assignedUserIds || [],
      });

      return unwrapData<Project>(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در ایجاد پروژه'));
    }
  },

  async importProjectsFromExcel(file: File): Promise<ProjectImportResult> {
    try {
      const formData = new FormData();

      formData.append('file', file);

      const response = await apiClient.post('/projects/import/excel', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      return unwrapData<ProjectImportResult>(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در ورود پروژه‌ها از اکسل'));
    }
  },

  async getProject(projectId: string): Promise<Project> {
    try {
      const response = await apiClient.get(`/projects/${projectId}`);

      return unwrapData<Project>(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در دریافت پروژه'));
    }
  },

  async updateProject(
    projectId: string,
    payload: Partial<ProjectPayload>,
  ): Promise<Project> {
    try {
      const requestPayload: Partial<ProjectPayload> = { ...payload };

      if ('dueDate' in requestPayload) {
        requestPayload.dueDate = requestPayload.dueDate || null;
      }

      const response = await apiClient.patch(
        `/projects/${projectId}`,
        requestPayload,
      );

      return unwrapData<Project>(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در ویرایش پروژه'));
    }
  },

  async deleteProject(projectId: string): Promise<void> {
    try {
      await apiClient.delete(`/projects/${projectId}`);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در حذف پروژه'));
    }
  },

  async assignUsers(projectId: string, userIds: string[]): Promise<Project> {
    try {
      const response = await apiClient.post(`/projects/${projectId}/users`, {
        userIds,
      });

      return unwrapData<Project>(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در تخصیص کاربران به پروژه'));
    }
  },

  async removeUser(projectId: string, userId: string): Promise<Project> {
    try {
      const response = await apiClient.delete(
        `/projects/${projectId}/users/${userId}`,
      );

      return unwrapData<Project>(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در حذف کاربر از پروژه'));
    }
  },

  async listTasks(projectId: string): Promise<ProjectTask[]> {
    try {
      const [tasksResponse, files] = await Promise.all([
        apiClient.get(`/projects/${projectId}/tasks`),
        fetchProjectFiles(projectId).catch(() => []),
      ]);

      const tasks = unwrapData<ProjectTask[]>(tasksResponse.data) || [];

      return attachFilesToTasks(tasks, files);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در دریافت وظایف پروژه'));
    }
  },

  async createTask(
    projectId: string,
    payload: ProjectTaskPayload,
  ): Promise<ProjectTask> {
    try {
      const response = await apiClient.post(
        `/projects/${projectId}/tasks`,
        buildTaskRequestPayload(payload),
      );

      const createdTask = unwrapData<ProjectTask>(response.data);
      const createdTaskId = getTaskId(createdTask);

      if (payload.files?.length && createdTaskId) {
        return await uploadTaskFilesRequest(
          projectId,
          createdTaskId,
          payload.files,
        );
      }

      return await attachProjectFilesToTask(projectId, createdTask);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در ایجاد وظیفه'));
    }
  },

  async updateTask(
    projectId: string,
    taskId: string,
    payload: Partial<ProjectTaskPayload>,
  ): Promise<ProjectTask> {
    try {
      const response = await apiClient.patch(
        `/projects/${projectId}/tasks/${taskId}`,
        buildTaskRequestPayload(payload),
      );

      const updatedTask = unwrapData<ProjectTask>(response.data);

      if (payload.files?.length) {
        return await uploadTaskFilesRequest(projectId, taskId, payload.files);
      }

      return await attachProjectFilesToTask(projectId, updatedTask);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در ویرایش وظیفه'));
    }
  },

  async closeTask(projectId: string, taskId: string): Promise<ProjectTask> {
    try {
      const response = await apiClient.patch(
        `/projects/${projectId}/tasks/${taskId}`,
        {
          status: 'done',
        },
        {
          headers: {
            'X-Toast-Success-Message': 'کار با موفقیت بسته شد.',
          },
        },
      );

      const task = unwrapData<ProjectTask>(response.data);

      return await attachProjectFilesToTask(projectId, task);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در بستن کار'));
    }
  },

  async uploadTaskFiles(
    projectId: string,
    taskId: string,
    files: File[],
  ): Promise<ProjectTask> {
    try {
      return await uploadTaskFilesRequest(projectId, taskId, files);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در ارسال فایل برای وظیفه'));
    }
  },

  async deleteTask(projectId: string, taskId: string): Promise<void> {
    try {
      await apiClient.delete(`/projects/${projectId}/tasks/${taskId}`);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در حذف وظیفه'));
    }
  },

  async listNotes(projectId: string): Promise<ProjectProgressNote[]> {
    try {
      const response = await apiClient.get(`/projects/${projectId}/notes`);

      return unwrapData<ProjectProgressNote[]>(response.data) || [];
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در دریافت یادداشت‌های پروژه'));
    }
  },

  async createNote(
    projectId: string,
    payload: CreateProjectNotePayload,
  ): Promise<ProjectProgressNote> {
    try {
      if (payload.file) {
        const formData = new FormData();

        formData.append('note', payload.note);

        if (payload.authorId) {
          formData.append('authorId', payload.authorId);
        }

        if (
          payload.progressPercent !== undefined &&
          payload.progressPercent !== null
        ) {
          formData.append('progressPercent', String(payload.progressPercent));
        }

        if (payload.statusSnapshot) {
          formData.append('statusSnapshot', payload.statusSnapshot);
        }

        formData.append('file', payload.file);

        const response = await apiClient.post(
          `/projects/${projectId}/notes`,
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          },
        );

        return unwrapData<ProjectProgressNote>(response.data);
      }

      const response = await apiClient.post(`/projects/${projectId}/notes`, {
        authorId: payload.authorId,
        note: payload.note,
        progressPercent: payload.progressPercent,
        statusSnapshot: payload.statusSnapshot,
      });

      return unwrapData<ProjectProgressNote>(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در ثبت گزارش کار'));
    }
  },

  async listFiles(
    projectId: string,
    params?: { standaloneOnly?: boolean },
  ): Promise<ProjectFile[]> {
    try {
      const response = await apiClient.get(`/projects/${projectId}/files`, {
        params,
      });

      return unwrapData<ProjectFile[]>(response.data) || [];
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در دریافت فایل‌های پروژه'));
    }
  },

  async uploadFile(
    projectId: string,
    payload: {
      file: File;
      category: string;
      progressNoteId?: string | null;
      taskId?: string | null;
    },
  ): Promise<ProjectFile> {
    try {
      const formData = new FormData();

      formData.append('file', payload.file);
      formData.append('category', payload.category || 'other');

      if (payload.progressNoteId) {
        formData.append('progressNoteId', payload.progressNoteId);
      }

      if (payload.taskId) {
        formData.append('taskId', payload.taskId);
      }

      const response = await apiClient.post(
        `/projects/${projectId}/files`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        },
      );

      return unwrapData<ProjectFile>(response.data);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در آپلود فایل پروژه'));
    }
  },

  async deleteFile(projectId: string, fileId: string): Promise<void> {
    try {
      await apiClient.delete(`/projects/${projectId}/files/${fileId}`);
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در حذف فایل پروژه'));
    }
  },

  async listCalendarEvents(params?: QueryParams): Promise<CalendarEvent[]> {
    try {
      const response = await apiClient.get('/projects/calendar/events', {
        params,
      });

      return unwrapData<CalendarEvent[]>(response.data) || [];
    } catch (error) {
      throw new Error(unwrapMessage(error, 'خطا در دریافت تقویم پروژه‌ها'));
    }
  },
};