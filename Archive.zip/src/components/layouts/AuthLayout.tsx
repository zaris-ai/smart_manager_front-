import { ReactNode } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ROUTES } from '@/config/constants';

interface AuthLayoutProps {
  children: ReactNode;
  title: string;
  subtitle?: string;
  showBackButton?: boolean;
}

const AuthLayout: React.FC<AuthLayoutProps> = ({
  children,
  title,
  subtitle,
  showBackButton = false,
}) => {
  return (
    <div className="flex min-h-screen" dir="rtl">
      <div className="flex w-full items-center justify-center bg-white p-6 dark:bg-gray-950 lg:w-1/2 lg:p-12">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center justify-between">
            <Link href={ROUTES.HOME} className="inline-block">
              <h1 className="text-3xl font-bold text-primary dark:text-blue-400">
                آوید
              </h1>
            </Link>
          </div>

          <div className="mb-8 text-right">
            {showBackButton && (
              <button
                onClick={() => window.history.back()}
                className="mb-4 flex items-center text-gray-600 transition-colors hover:text-primary dark:text-gray-400"
                type="button"
              >
                <svg
                  className="ml-2 h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
                بازگشت
              </button>
            )}

            <h2 className="mb-2 text-xl font-bold text-gray-900 dark:text-gray-100">
              {title}
            </h2>

            {subtitle && (
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {subtitle}
              </p>
            )}
          </div>

          <div className="space-y-6">{children}</div>

          <p className="mt-8 text-center text-xs text-gray-500 dark:text-gray-400">
            با ورود به سامانه، قوانین استفاده و سیاست حفظ حریم خصوصی را می‌پذیرید.
          </p>
        </div>
      </div>

      <div className="relative hidden overflow-hidden lg:flex lg:w-1/2">
        <div className="absolute inset-0">
          <Image
            src="/Image/side_image.png"
            alt="تصویر ورود به سامانه"
            fill
            className="object-cover"
            priority
          />
        </div>

        <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/60 to-primary/80" />

        <div className="relative z-10 flex w-full flex-col items-center justify-center p-12 text-white">
          <div className="max-w-lg text-center">
            <h2 className="mb-6 text-4xl font-bold drop-shadow-lg">
              خوش آمدید
            </h2>
            <p className="mb-8 text-xl text-white/90 drop-shadow-md">
              مدیریت کاربران، پروژه‌ها و فرآیندهای کاری شرکت در یک پنل یکپارچه.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;