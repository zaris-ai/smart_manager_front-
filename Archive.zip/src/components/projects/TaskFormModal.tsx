import { useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { userService } from '@/services/user.service';
import {
  getReferenceId,
  getTaskId,
  getUserDisplayName,
  projectPriorityLabels,
  ProjectTask,
  ProjectTaskPayload,
  projectTaskStatusLabels,
  UserSummary,
} from '@/types/project';
import { XMarkIcon } from '@heroicons/react/24/outline';

type TaskFormModalProps = {
  open: boolean;
  task?: ProjectTask | null;
  onClose: () => void;
  onSubmit: (payload: ProjectTaskPayload) => Promise<void>;
};

const toDateInputValue = (value?: string | null): string => {
  if (!value) return '';

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return '';

  return date.toISOString().slice(0, 10);
};

const getUserId = (user: UserSummary): string => {
  return user.id || user._id || '';
};

export const TaskFormModal = ({
  open,
  task,
  onClose,
  onSubmit,
}: TaskFormModalProps) => {
  const [users, setUsers] = useState<UserSummary[]>([]);
  const [error, setError] = useState('');

  const isEditMode = Boolean(task && getTaskId(task));

  const {
    register,
    handleSubmit,
    reset,
    formState: { isSubmitting },
  } = useForm<ProjectTaskPayload>({
    defaultValues: {
      title: '',
      description: '',
      assignedUserIds: [],
      status: 'todo',
      priority: 'medium',
      startDate: '',
      dueDate: '',
    },
  });

  const activeUsers = useMemo(() => {
    return users.filter((user) => user.isActive !== false);
  }, [users]);

  useEffect(() => {
    if (!open) return;

    const loadUsers = async () => {
      try {
        setError('');

        const items = await userService.listUsers();

        setUsers(items);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'خطا در دریافت کاربران');
      }
    };

    loadUsers();
  }, [open]);

  useEffect(() => {
    if (!open) return;

    if (task) {
      reset({
        title: task.title || '',
        description: task.description || '',
        assignedUserIds:
          task.assignedUserIds?.map((user) => getReferenceId(user)).filter(Boolean) ||
          [],
        status: task.status || 'todo',
        priority: task.priority || 'medium',
        startDate: toDateInputValue(task.startDate),
        dueDate: toDateInputValue(task.dueDate),
      });
    } else {
      reset({
        title: '',
        description: '',
        assignedUserIds: [],
        status: 'todo',
        priority: 'medium',
        startDate: '',
        dueDate: '',
      });
    }

    setError('');
  }, [open, task, reset]);

  const submitHandler = async (values: ProjectTaskPayload) => {
    try {
      setError('');

      await onSubmit({
        ...values,
        startDate: values.startDate || null,
        dueDate: values.dueDate || null,
        assignedUserIds: values.assignedUserIds || [],
      });

      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در ذخیره وظیفه');
    }
  };

  if (!open) return null;

  return (
    <dialog className="modal modal-open" dir="rtl">
      <div className="modal-box max-w-4xl bg-white dark:bg-gray-900">
        <div className="mb-6 flex items-start justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">
              {isEditMode ? 'ویرایش وظیفه' : 'ایجاد وظیفه جدید'}
            </h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              وظایف، مبنای اصلی نمایش در تقویم و پیگیری اجرای پروژه هستند.
            </p>
          </div>

          <button
            type="button"
            className="btn btn-ghost btn-sm btn-circle"
            onClick={onClose}
          >
            <XMarkIcon className="h-5 w-5" />
          </button>
        </div>

        {error ? (
          <div className="alert alert-error mb-5">
            <span>{error}</span>
          </div>
        ) : null}

        <form onSubmit={handleSubmit(submitHandler)} className="space-y-5">
          <label className="form-control">
            <span className="label label-text">عنوان وظیفه</span>
            <input
              className="input input-bordered"
              placeholder="مثلاً طراحی API تقویم پروژه"
              {...register('title', { required: true })}
            />
          </label>

          <label className="form-control">
            <span className="label label-text">توضیحات</span>
            <textarea
              className="textarea textarea-bordered min-h-24"
              placeholder="توضیح کوتاه درباره کاری که باید انجام شود."
              {...register('description')}
            />
          </label>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <label className="form-control">
              <span className="label label-text">وضعیت</span>
              <select className="select select-bordered" {...register('status')}>
                {Object.entries(projectTaskStatusLabels).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </select>
            </label>

            <label className="form-control">
              <span className="label label-text">اولویت</span>
              <select className="select select-bordered" {...register('priority')}>
                {Object.entries(projectPriorityLabels).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </select>
            </label>

            <label className="form-control">
              <span className="label label-text">تاریخ شروع</span>
              <input
                type="date"
                className="input input-bordered"
                {...register('startDate')}
              />
            </label>

            <label className="form-control">
              <span className="label label-text">موعد انجام</span>
              <input
                type="date"
                className="input input-bordered"
                {...register('dueDate')}
              />
            </label>
          </div>

          <label className="form-control">
            <span className="label label-text">کاربران مسئول</span>
            <select
              multiple
              className="select select-bordered min-h-36"
              {...register('assignedUserIds')}
            >
              {activeUsers.map((user) => (
                <option key={getUserId(user)} value={getUserId(user)}>
                  {getUserDisplayName(user)}
                </option>
              ))}
            </select>
            <span className="label-text-alt mt-2 text-gray-500">
              برای انتخاب چند کاربر از Ctrl یا Cmd استفاده کنید.
            </span>
          </label>

          <div className="modal-action">
            <button type="button" className="btn btn-ghost" onClick={onClose}>
              انصراف
            </button>

            <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
              {isSubmitting
                ? 'در حال ذخیره...'
                : isEditMode
                  ? 'ذخیره تغییرات'
                  : 'ایجاد وظیفه'}
            </button>
          </div>
        </form>
      </div>
    </dialog>
  );
};