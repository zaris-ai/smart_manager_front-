import { Button, Input } from '@/components/ui';
import { LockClosedIcon, UserIcon } from '@heroicons/react/24/outline';
import { zodResolver } from '@hookform/resolvers/zod';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';

const loginSchema = z.object({
  username: z.string().trim().min(1, 'نام کاربری الزامی است.'),
  password: z.string().min(1, 'رمز عبور الزامی است.'),
});

type LoginFormData = z.infer<typeof loginSchema>;

function normalizeAuthError(error: string): string {
  if (error === 'CredentialsSignin') {
    return 'نام کاربری یا رمز عبور اشتباه است.';
  }

  if (error === 'RefreshAccessTokenError') {
    return 'نشست شما منقضی شده است. دوباره وارد شوید.';
  }

  return error || 'خطا در ورود به سامانه.';
}

const LoginForm: React.FC = () => {
  const router = useRouter();

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    try {
      setIsLoading(true);
      setError('');
      
      const result = await signIn('credentials', {
        username: data.username,
        password: data.password,
        redirect: false,
      }); 
      
      if (!result) {
        setError('پاسخی از سرویس احراز هویت دریافت نشد.');
        return;
      }

      if (result.error) {
        setError(normalizeAuthError(result.error));
        return;
      }

      await router.replace('/dashboard');
    } catch (err) {
      
      const message =
        err instanceof Error
          ? err.message
          : 'خطای غیرمنتظره‌ای رخ داده است. دوباره تلاش کنید.';

      setError(message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5 text-right" dir="rtl">
      {error && (
        <div className="rounded-lg bg-red-50 p-3 text-sm text-red-600 dark:bg-red-900/20 dark:text-red-400">
          {error}
        </div>
      )}

      <Input
        {...register('username')}
        type="text"
        label="نام کاربری"
        placeholder="نام کاربری خود را وارد کنید"
        error={errors.username?.message}
        leftIcon={<UserIcon className="h-5 w-5" />}
        dir="ltr"
        autoComplete="username"
        autoFocus
      />

      <Input
        {...register('password')}
        type="password"
        label="رمز عبور"
        placeholder="رمز عبور خود را وارد کنید"
        error={errors.password?.message}
        leftIcon={<LockClosedIcon className="h-5 w-5" />}
        dir="ltr"
        autoComplete="current-password"
      />

      <Button type="submit" fullWidth isLoading={isLoading}>
        ورود به سامانه
      </Button>
    </form>
  );
};

export default LoginForm;