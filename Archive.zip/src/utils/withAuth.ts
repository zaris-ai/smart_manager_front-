import { GetServerSideProps, GetServerSidePropsContext } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth/options';

export function withAuth(gssp?: GetServerSideProps): GetServerSideProps {
  return async (context: GetServerSidePropsContext) => {
    const session = await getServerSession(
      context.req,
      context.res,
      authOptions,
    );

    if (!session || session.error === 'RefreshAccessTokenError') {
      return {
        redirect: {
          destination: '/auth/login?expired=1',
          permanent: false,
        },
      };
    }

    if (!gssp) {
      return {
        props: {
          session,
        },
      };
    }

    const gsspData = await gssp(context);

    if ('props' in gsspData) {
      return {
        ...gsspData,
        props: {
          ...gsspData.props,
          session,
        },
      };
    }

    return gsspData;
  };
}